using System.Reflection;

[assembly: AssemblyProduct ("MonoDevelop")]
[assembly: AssemblyTitle ("IronPython Language Binding")]
[assembly: AssemblyDescription ("IronPython Language Binding")]
[assembly: AssemblyVersion ("2.8")]
[assembly: AssemblyCopyright ("MIT X11")]